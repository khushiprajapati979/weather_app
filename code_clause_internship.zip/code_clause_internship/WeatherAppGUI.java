import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class WeatherAppGUI {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Weather App");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Enter City:");
        label.setBounds(50, 50, 100, 30);

        JTextField cityField = new JTextField();
        cityField.setBounds(150, 50, 150, 30);

        JButton button = new JButton("Get Weather");
        button.setBounds(120, 100, 150, 30);

        JTextArea resultArea = new JTextArea();
        resultArea.setBounds(50, 150, 300, 100);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);

        frame.add(label);
        frame.add(cityField);
        frame.add(button);
        frame.add(resultArea);
        frame.setLayout(null);
        frame.setVisible(true);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String city = cityField.getText();
                String apiKey = "fc2a88f3a336e5628f26a3c23205ecab"; 
                String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

                try {
                    URL url = new URL(urlString);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String inputLine;
                    StringBuffer content = new StringBuffer();
                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }
                    in.close();

                    resultArea.setText("Weather Data:\n" + content.toString());

                } catch (Exception ex) {
                    resultArea.setText("Error retrieving weather data.");
                    ex.printStackTrace();
                }
            }
        });
    }
}